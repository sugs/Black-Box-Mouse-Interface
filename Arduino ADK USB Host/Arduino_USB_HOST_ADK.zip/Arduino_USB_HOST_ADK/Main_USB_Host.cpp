#include <Arduino.h>

void setup();
void loop();
void init();

int main(void)
{
	init();

	setup();

	for (;;) {
		loop();
	}
	return 0;
}

void setup(){

	// Check choice (default = Emulation).
		// check pins.

	// Setup objects.
		// complier choice... MOUSE, JOYSTICK, MOUSE+JOYSTIK

	// Start Debug Engine.

	// Start process.

}

void loop(){

	// check if emulation | real usb device.

	// if usb device,
		// get number of packets. <-|
		// get usb data. -----------|
		// assemble usb frame
		// send frame to host

	// if emulation,
		// get random values
		// assemble usb frame
		// send frame to host
}
